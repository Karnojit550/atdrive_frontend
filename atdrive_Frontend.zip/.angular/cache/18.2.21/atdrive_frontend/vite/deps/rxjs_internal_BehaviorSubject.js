import {
  BehaviorSubject
} from "./chunk-KWR7RS3Y.js";
export {
  BehaviorSubject
};
//# sourceMappingURL=rxjs_internal_BehaviorSubject.js.map
